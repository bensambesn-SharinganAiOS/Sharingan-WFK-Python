# from https://gist.githubusercontent.com/SadProcessor/3e413f9542b01ee90979/raw/463c518c90fca50a2cee594d1b619a0d3fb5bed5/Get-RickAstley.ps1
function Get-RickAstley {
    [console]::beep(440,150)#A
    [console]::beep(493,150)#B
    [console]::beep(587,150)#D
    [console]::beep(493,150)#B
    Start-Sleep -m 20
    [console]::beep(698,400)#F
    [console]::beep(698,400)#F
    [console]::beep(659,500)#E
    Start-Sleep -m 50
    ##
    [console]::beep(440,150)#A
    [console]::beep(493,150)#B
    [console]::beep(523,150)#C
    [console]::beep(444,150)#B
    Start-Sleep -m 20
    [console]::beep(659,400)#E
    [console]::beep(659,400)#E
    [console]::beep(587,400)#D
    [console]::beep(523,100)#C
    [console]::beep(440,100)#A
    Start-Sleep -m 50
    ##
    [console]::beep(440,150)#A
    [console]::beep(493,150)#B
    [console]::beep(587,150)#D
    [console]::beep(493,150)#B
    Start-Sleep -m 20
    [console]::beep(587,400)#D
    [console]::beep(659,400)#E
    [console]::beep(523,400)#C
    [console]::beep(493,150)#B
    [console]::beep(440,150)#A
    Start-Sleep -m 20
    [console]::beep(440,150)#A
    [console]::beep(659,250)#E
    [console]::beep(587,250)#D
    Start-Sleep -m 200
    ##
    [console]::beep(440,150)#A
    [console]::beep(493,150)#B
    [console]::beep(587,150)#D
    [console]::beep(493,150)#B
    Start-Sleep -m 20
    [console]::beep(698,400)#F
    [console]::beep(698,400)#F
    [console]::beep(659,500)#E
    Start-Sleep -m 50
    ##
    [console]::beep(440,150)#A
    [console]::beep(493,150)#B
    [console]::beep(523,150)#C
    [console]::beep(440,150)#A
    Start-Sleep -m 20
    [console]::beep(880,600)#A
    [console]::beep(523,400)#C
    [console]::beep(587,400)#D
    [console]::beep(659,100)#E
    [console]::beep(587,100)#D
    start-sleep -m 50
    ##
    [console]::beep(440,150)#A
    [console]::beep(493,150)#B
    [console]::beep(587,150)#D
    [console]::beep(493,150)#B
    Start-Sleep -m 20
    [console]::beep(587,400)#D
    [console]::beep(659,400)#E
    [console]::beep(523,400)#C
    [console]::beep(493,150)#B
    [console]::beep(440,150)#A
    Start-Sleep -m 50
    [console]::beep(440,150)#A
    [console]::beep(659,250)#E
    [console]::beep(587,250)#D
}