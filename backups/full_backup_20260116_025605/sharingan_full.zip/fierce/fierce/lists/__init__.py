import pathlib


CURDIR = pathlib.Path(__file__).parent
DEFAULT_LIST = CURDIR / "default.txt"
_20000_LIST = "20000.txt"
_5000_LIST = "5000.txt"
