#!/usr/bin/env python3
"""
Sharingan OS - Full Backup System
Backup complet avant repartage à zéro
"""

import os
import sys
import json
import zipfile
import hashlib
import subprocess
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any
import requests

# Configuration
GITHUB_TOKEN = "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"
REPO_OWNER = "bensambesn-SharinganAiOS"
REPO_NAME = "Sharingan-WFK-Python"
BASE_DIR = Path("/root/Projets/Sharingan-WFK-Python")

headers = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
    'User-Agent': 'Sharingan-OS/1.0'
}


def calculate_checksum(file_path: Path) -> str:
    """Calculer checksum MD5 d'un fichier"""
    md5 = hashlib.md5()
    with open(file_path, 'rb') as f:
        for chunk in iter(lambda: f.read(4096), b""):
            md5.update(chunk)
    return md5.hexdigest()


def create_local_backup() -> Dict[str, Any]:
    """Créer un backup local complet"""
    print("=" * 60)
    print("CRÉATION BACKUP LOCAL")
    print("=" * 60)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = BASE_DIR / "backups" / f"full_backup_{timestamp}"
    backup_dir.mkdir(parents=True, exist_ok=True)
    
    # Créer archive zip
    zip_path = backup_dir / "sharingan_full.zip"
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(BASE_DIR):
            # Exclure certains dossiers
            dirs[:] = [d for d in dirs if d not in ['__pycache__', 'backups', '.git', 'node_modules', '.venv']]
            
            for file in files:
                file_path = Path(root) / file
                if file_path.suffix in ['.pyc', '.pyo', '.log']:
                    continue
                arcname = file_path.relative_to(BASE_DIR)
                zipf.write(file_path, arcname)
                print(f"  Added: {arcname}")
    
    # Créer fichier manifest
    manifest = {
        "timestamp": datetime.now().isoformat(),
        "version": "3.0.0",
        "backup_type": "full",
        "files_count": len([f for f in BASE_DIR.rglob('*') if f.is_file()]),
        "zip_size_mb": round(zip_path.stat().st_size / (1024*1024), 2),
        "checksum": calculate_checksum(zip_path),
        "contents": {
            "main_app": "sharingan_app/_internal/",
            "tools": "tools/",
            "scripts": list(BASE_DIR.glob("*.py")),
            "docs": list(BASE_DIR.glob("docs/*")),
            "data": list((BASE_DIR / "sharingan_app/_internal/data").rglob("*"))
        }
    }
    
    manifest_path = backup_dir / "manifest.json"
    with open(manifest_path, 'w') as f:
        json.dump(manifest, f, indent=2, default=str)
    
    # Sauvegarder les bases de données critiques
    critical_files = [
        BASE_DIR / "sharingan_app/_internal/data" / "genome_memory.json",
        BASE_DIR / "sharingan_app/_internal/data" / "ai_memory.json",
        BASE_DIR / "sharingan_app/_internal/data" / "learning_patterns.json",
        BASE_DIR / "sharingan_app/_internal/psychic_backups" / "*.backup",
    ]
    
    critical_dir = backup_dir / "critical_data"
    critical_dir.mkdir(exist_ok=True)
    
    for pattern in critical_files:
        for f in BASE_DIR.glob(str(pattern)):
            dest = critical_dir / f.name
            with open(f, 'r') as src, open(dest, 'w') as dst:
                dst.write(src.read())
            print(f"  Critical: {f.name}")
    
    print(f"\n✓ Backup local créé: {backup_dir}")
    print(f"  Archive: {zip_path.name} ({manifest['zip_size_mb']} MB)")
    print(f"  Fichiers: {manifest['files_count']}")
    
    return {
        "backup_dir": str(backup_dir),
        "zip_path": str(zip_path),
        "manifest": manifest
    }


def upload_to_github() -> Dict[str, Any]:
    """Uploader le backup vers GitHub Releases"""
    print("\n" + "=" * 60)
    print("UPLOAD VERS GITHUB RELEASES")
    print("=" * 60)
    
    # Créer le tag et release
    tag_name = f"backup-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    
    # Créer le tag
    tag_data = {
        "tag_name": tag_name,
        "tag_message": "Full system backup",
        "object": "head",
        "message": f"Backup {datetime.now().isoformat()}"
    }
    
    response = requests.post(
        f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/git/tags",
        headers=headers,
        json=tag_data
    )
    
    if response.status_code not in [201, 422]:
        print(f"Erreur création tag: {response.status_code}")
        return {"success": False, "error": response.text}
    
    # Créer la release
    release_data = {
        "tag_name": tag_name,
        "name": f"Full Backup {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        "body": "# Full System Backup\n\nSauvegarde complète avant repartage.",
        "draft": False,
        "prerelease": False
    }
    
    response = requests.post(
        f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/releases",
        headers=headers,
        json=release_data
    )
    
    if response.status_code not in [201, 422]:
        print(f"Erreur création release: {response.status_code}")
        return {"success": False, "error": response.text}
    
    release = response.json()
    upload_url = release.get("upload_url", "").replace("{?name,label}", "")
    
    # Uploader l'archive
    local_backup = create_local_backup()
    zip_path = Path(local_backup["zip_path"])
    
    if zip_path.exists():
        with open(zip_path, 'rb') as f:
            content = f.read()
        
        response = requests.post(
            f"{upload_url}?name={zip_path.name}",
            headers={
                **headers,
                'Content-Type': 'application/zip'
            },
            data=content
        )
        
        if response.status_code == 201:
            print(f"✓ Archive uploadée: {zip_path.name}")
            return {
                "success": True,
                "tag": tag_name,
                "release_url": release.get("html_url"),
                "download_url": response.json().get("browser_download_url")
            }
    
    return {"success": False, "error": "Upload failed"}


def delete_github_repo() -> Dict[str, Any]:
    """Supprimer le repository GitHub"""
    print("\n" + "=" * 60)
    print("SUPPRESSION REPOSITORY GITHUB")
    print("=" * 60)
    
    print(f"Repository: {REPO_OWNER}/{REPO_NAME}")
    print("⚠️  ATTENTION: Cette action est IRRÉVERSIBLE!")
    
    response = requests.delete(
        f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}",
        headers=headers
    )
    
    if response.status_code == 204:
        print("✓ Repository supprimé avec succès!")
        return {"success": True}
    else:
        print(f"Erreur: {response.status_code}")
        return {"success": False, "error": response.text}


def create_new_repo() -> Dict[str, Any]:
    """Créer un nouveau repository"""
    print("\n" + "=" * 60)
    print("CRÉATION NOUVEAU REPOSITORY")
    print("=" * 60)
    
    repo_data = {
        "name": REPO_NAME,
        "description": "Sharingan OS - AI-Powered Cybersecurity Operating System",
        "private": False,
        "auto_init": False
    }
    
    response = requests.post(
        "https://api.github.com/user/repos",
        headers=headers,
        json=repo_data
    )
    
    if response.status_code == 201:
        new_repo = response.json()
        print(f"✓ Repository créé: {new_repo['html_url']}")
        return {"success": True, "repo": new_repo}
    else:
        print(f"Erreur: {response.status_code}")
        return {"success": False, "error": response.text}


def push_to_new_repo() -> Dict[str, Any]:
    """Pusher le code vers le nouveau repository"""
    print("\n" + "=" * 60)
    print("PUSH VERS NOUVEAU REPOSITORY")
    print("=" * 60)
    
    try:
        # Configurer remote
        remote_url = f"https://{GITHUB_TOKEN}@github.com/{REPO_OWNER}/{REPO_NAME}.git"
        
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            cwd=BASE_DIR,
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            subprocess.run(
                ["git", "remote", "set-url", "origin", remote_url],
                cwd=BASE_DIR,
                check=True
            )
        
        # Ajouter tous les fichiers
        subprocess.run(
            ["git", "add", "."],
            cwd=BASE_DIR,
            capture_output=True
        )
        
        # Créer commit
        commit_result = subprocess.run(
            ["git", "commit", "-m", f"Initial commit - Fresh start {datetime.now().isoformat()}"],
            cwd=BASE_DIR,
            capture_output=True,
            text=True
        )
        
        if commit_result.returncode != 0:
            # Peut-être qu'il n'y a pas de changements ou déjà commité
            print(f"Commit: {commit_result.stderr}")
        
        # Push
        push_result = subprocess.run(
            ["git", "push", "-u", "origin", "main"],
            cwd=BASE_DIR,
            capture_output=True,
            text=True
        )
        
        if push_result.returncode == 0:
            print("✓ Code pushé avec succès!")
            return {"success": True}
        else:
            # Essayer master si main échoue
            push_result = subprocess.run(
                ["git", "push", "-u", "origin", "master"],
                cwd=BASE_DIR,
                capture_output=True,
                text=True
            )
            if push_result.returncode == 0:
                print("✓ Code pushé (master branch)!")
                return {"success": True}
            
            print(f"Erreur push: {push_result.stderr}")
            return {"success": False, "error": push_result.stderr}
            
    except Exception as e:
        print(f"Erreur: {e}")
        return {"success": False, "error": str(e)}


def main():
    print("\n" + "=" * 60)
    print("SHARINGAN OS - FULL BACKUP & CLEAN RESTART")
    print("=" * 60)
    print(f"Token: {GITHUB_TOKEN[:10]}...")
    print(f"Repository: {REPO_OWNER}/{REPO_NAME}")
    print()
    
    results = {}
    
    # Étape 1: Backup local
    results["local_backup"] = create_local_backup()
    
    # Étape 2: Upload vers GitHub Releases
    print("\nUpload vers GitHub Releases? (o/n)")
    choice = input("> ").lower().strip()
    
    if choice == 'o':
        results["github_release"] = upload_to_github()
    
    # Étape 3: Supprimer l'ancien repo
    print("\n" + "=" * 60)
    print("ATTENTION: PROCHAINE ÉTAPE - SUPPRESSION REPOSITORY")
    print("=" * 60)
    print("Tapez 'SUPPRIMER' pour confirmer la suppression du repository GitHub")
    print("Sinon, tapez Entrée pour annuler.")
    
    confirm = input("> ").strip()
    
    if confirm == "SUPPRIMER":
        results["delete_repo"] = delete_github_repo()
        
        if results.get("delete_repo", {}).get("success"):
            # Étape 4: Créer nouveau repo
            results["new_repo"] = create_new_repo()
            
            if results.get("new_repo", {}).get("success"):
                # Étape 5: Push le code
                results["push"] = push_to_new_repo()
    else:
        print("Suppression annulée.")
        results["delete_repo"] = {"success": False, "error": "Cancelled by user"}
    
    # Rapport final
    print("\n" + "=" * 60)
    print("RAPPORT FINAL")
    print("=" * 60)
    print(f"Backup local: {results.get('local_backup', {}).get('backup_dir', 'N/A')}")
    print(f"GitHub Release: {'✓' if results.get('github_release', {}).get('success') else '✗'}")
    print(f"Repo supprimé: {'✓' if results.get('delete_repo', {}).get('success') else '✗'}")
    print(f"Nouveau repo: {'✓' if results.get('new_repo', {}).get('success') else '✗'}")
    print(f"Code pushé: {'✓' if results.get('push', {}).get('success') else '✗'}")
    
    return results


if __name__ == "__main__":
    main()
